class CreateIntakes < ActiveRecord::Migration[5.0]
  def change
    create_table :intakes do |t|
      t.integer :user_id
      t.string :intake_no

      t.timestamps
    end
  end
end
