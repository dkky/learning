# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
names = ["haha","hehe", "hoho"]

names.each do |x|
  User.create(name: x)
end

intake_date = ["dec 2016", "jan 2017", "feb 2017"]

3.times do
  Intake.create(intake_no: intake_date, user_id: [1,2,3].sample)
end

bootcamps = ["ios","webdev"]

6.times do
  Registration.create(bootcamp: bootcamps.sample, user_id: [1,2,3].sample, intake_id: [1,2,3].sample)
end
