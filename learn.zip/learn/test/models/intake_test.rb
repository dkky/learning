require 'test_helper'

class IntakeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
